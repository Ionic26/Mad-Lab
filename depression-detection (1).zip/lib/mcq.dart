import 'package:flutter/material.dart';

class PHQ9Page extends StatefulWidget {
  final String fullName;

  PHQ9Page({required this.fullName});

  @override
  _PHQ9PageState createState() => _PHQ9PageState();
}

class _PHQ9PageState extends State<PHQ9Page> {
  List<int?> _answers =
      List.filled(10, null); // Stores answers for 10 questions

  final List<String> _questions = [
    "Little interest or pleasure in doing things?",
    "Feeling down, depressed, or hopeless?",
    "Trouble falling or staying asleep, or sleeping too much?",
    "Feeling tired or having little energy?",
    "Poor appetite or overeating?",
    "Feeling bad about yourself or that you are a failure?",
    "Trouble concentrating on things like reading or watching TV?",
    "Moving or speaking so slowly or being fidgety/restless?",
    "Thoughts that you would be better off dead or hurting yourself?",
    "Feeling nervous, anxious, or on edge?",
  ];

  final List<String> _options = [
    "Not at all (0)",
    "Several days (1)",
    "More than half the days (2)",
    "Nearly every day (3)"
  ];

  void _calculateScore() {
    if (_answers.contains(null)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please answer all questions!")),
      );
      return;
    }

    int totalScore = _answers.fold(0, (sum, value) => sum + (value ?? 0));

    String result;
    if (totalScore >= 0 && totalScore <= 4) {
      result = "Minimal or No Depression";
    } else if (totalScore >= 5 && totalScore <= 9) {
      result = "Mild Depression";
    } else if (totalScore >= 10 && totalScore <= 14) {
      result = "Moderate Depression";
    } else if (totalScore >= 15 && totalScore <= 19) {
      result = "Moderately Severe Depression";
    } else {
      result = "Severe Depression";
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Test Result"),
          content: Text("Your depression level: $result"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("PHQ-9 Depression Test")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: _questions.length,
                itemBuilder: (context, index) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("${index + 1}. ${_questions[index]}",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      Column(
                        children: List.generate(_options.length, (optionIndex) {
                          return RadioListTile<int>(
                            title: Text(_options[optionIndex]),
                            value: optionIndex,
                            groupValue: _answers[index],
                            onChanged: (value) {
                              setState(() {
                                _answers[index] = value;
                              });
                            },
                          );
                        }),
                      ),
                      SizedBox(height: 10),
                    ],
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: _calculateScore,
              child: Text("Submit Test"),
            ),
          ],
        ),
      ),
    );
  }
}
