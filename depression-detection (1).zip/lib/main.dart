import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'mcq.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: '',
    anonKey: '',
  );
  runApp(MyApp());
}

final supabase = Supabase.instance.client;

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AuthPage(),
    );
  }
}

// ==================== AUTH PAGE ====================
class AuthPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Welcome to MindCare",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => LoginPage()));
              },
              child: Text("Get Started"),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== LOGIN PAGE ====================
class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  Future<void> login() async {
    try {
      final response = await supabase.auth.signInWithPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      if (response.session != null) {
        final user = response.user!;
        String fullName = user.userMetadata?['full_name'] ?? "User";

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage(fullName: fullName)),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Login failed: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
                controller: emailController,
                decoration: InputDecoration(labelText: "Email")),
            TextField(
                controller: passwordController,
                decoration: InputDecoration(labelText: "Password"),
                obscureText: true),
            SizedBox(height: 20),
            ElevatedButton(onPressed: login, child: Text("Login")),
            TextButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => SignupPage()));
              },
              child: Text("Don't have an account? Sign up"),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== SIGNUP PAGE ====================
class SignupPage extends StatefulWidget {
  @override
  _SignupPageState createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  Future<void> signUp() async {
    try {
      final AuthResponse response = await supabase.auth.signUp(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
        data: {
          'full_name': nameController.text.trim(),
        },
      );

      if (response.user != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Signup failed: Unknown error")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Signup failed: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Sign Up")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: "Full Name")),
            TextField(
                controller: emailController,
                decoration: InputDecoration(labelText: "Email")),
            TextField(
                controller: passwordController,
                decoration: InputDecoration(labelText: "Password"),
                obscureText: true),
            SizedBox(height: 20),
            ElevatedButton(onPressed: signUp, child: Text("Sign Up")),
          ],
        ),
      ),
    );
  }
}

// ==================== HOME PAGE ====================
class HomePage extends StatelessWidget {
  final String fullName;

  HomePage({required this.fullName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Welcome, $fullName")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Hello, $fullName!", style: TextStyle(fontSize: 24)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => PHQ9Page(fullName: fullName)));
              },
              child: Text("Take PHQ-9 Test"),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== PHQ-9 QUESTIONNAIRE PAGE ====================
class PHQ9Page extends StatefulWidget {
  final String fullName;
  PHQ9Page({required this.fullName});
  @override
  _PHQ9PageState createState() => _PHQ9PageState();
}

class _PHQ9PageState extends State<PHQ9Page> {
  List<int?> _answers = List.filled(10, null);
  final List<String> _questions = [
    "Little interest or pleasure in doing things?",
    "Feeling down, depressed, or hopeless?",
    "Trouble falling or staying asleep, or sleeping too much?",
    "Feeling tired or having little energy?",
    "Poor appetite or overeating?",
    "Feeling bad about yourself or that you are a failure?",
    "Trouble concentrating on things like reading or watching TV?",
    "Moving or speaking so slowly or being fidgety/restless?",
    "Thoughts that you would be better off dead or hurting yourself?",
    "Feeling nervous, anxious, or on edge?",
  ];
  final List<String> _options = [
    "Not at all (0)",
    "Several days (1)",
    "More than half the days (2)",
    "Nearly every day (3)"
  ];

  void _calculateScore() {
    if (_answers.contains(null)) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Please answer all questions!")));
      return;
    }
    int totalScore = _answers.fold(0, (sum, value) => sum + (value ?? 0));
    String result;
    if (totalScore <= 4)
      result = "Minimal or No Depression";
    else if (totalScore <= 9)
      result = "Mild Depression";
    else if (totalScore <= 14)
      result = "Moderate Depression";
    else if (totalScore <= 19)
      result = "Moderately Severe Depression";
    else
      result = "Severe Depression";

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Test Result"),
        content: Text("Your depression level: $result"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("OK"))
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("PHQ-9 Depression Test")),
      body: ListView.builder(
        itemCount: _questions.length,
        itemBuilder: (context, index) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("${index + 1}. ${_questions[index]}",
                style: TextStyle(fontWeight: FontWeight.bold)),
            ..._options.asMap().entries.map((entry) => RadioListTile<int>(
                  title: Text(entry.value),
                  value: entry.key,
                  groupValue: _answers[index],
                  onChanged: (value) => setState(() => _answers[index] = value),
                )),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: _calculateScore, child: Icon(Icons.check)),
    );
  }
}
